package com.example.codeflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
