class SinhVien {
  final String ma;
  final String hoVaTen;
  final DateTime ngayhethan;
  final double diemTotNghiep;

  SinhVien({
    required this.ma,
    required this.hoVaTen,
    required this.ngayhethan,
    required this.diemTotNghiep,
  });
}
